const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-D3CpLOYy.js","./index-BNmPlpnc.js","./index-DVwk1rnX.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BNmPlpnc.js";const _=r("Share",{web:()=>t(()=>import("./web-D3CpLOYy.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};

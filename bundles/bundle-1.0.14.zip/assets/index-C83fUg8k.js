const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-C9-x45JX.js","./index-S3Y2tA3z.js","./index-DVwk1rnX.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-S3Y2tA3z.js";const _=r("Share",{web:()=>t(()=>import("./web-C9-x45JX.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};

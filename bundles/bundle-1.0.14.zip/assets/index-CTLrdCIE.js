const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-B_hu0wfa.js","./index-S3Y2tA3z.js","./index-DVwk1rnX.css"])))=>i.map(i=>d[i]);
import{r as i,_ as e}from"./index-S3Y2tA3z.js";const t=i("SocialLogin",{web:()=>e(()=>import("./web-B_hu0wfa.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(o=>new o.SocialLoginWeb)});export{t as SocialLogin};

const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-hf7HrCdD.js","./index-CqlXgCVc.js","./index-DVwk1rnX.css"])))=>i.map(i=>d[i]);
import{r as i,_ as e}from"./index-CqlXgCVc.js";const t=i("SocialLogin",{web:()=>e(()=>import("./web-hf7HrCdD.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(o=>new o.SocialLoginWeb)});export{t as SocialLogin};

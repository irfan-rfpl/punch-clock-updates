const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BjzFzPRW.js","./index-De1gRU0I.js","./index-DVwk1rnX.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-De1gRU0I.js";const _=r("Share",{web:()=>t(()=>import("./web-BjzFzPRW.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};

const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DVVWh_Yg.js","./index-De1gRU0I.js","./index-DVwk1rnX.css"])))=>i.map(i=>d[i]);
import{r as i,_ as e}from"./index-De1gRU0I.js";const t=i("SocialLogin",{web:()=>e(()=>import("./web-DVVWh_Yg.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(o=>new o.SocialLoginWeb)});export{t as SocialLogin};

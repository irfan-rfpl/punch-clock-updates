const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-B8lr3zTB.js","./index-9bhJ_fa0.js","./index-DVwk1rnX.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-9bhJ_fa0.js";const _=r("Share",{web:()=>t(()=>import("./web-B8lr3zTB.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};

const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DzgR8SHU.js","./index-jWl_StjY.js","./index-DVwk1rnX.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-jWl_StjY.js";const _=r("Share",{web:()=>t(()=>import("./web-DzgR8SHU.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
